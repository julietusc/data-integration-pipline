# Lauren Pickard, lpickard@usc.edu
# ITP116 Spring 2022 11 am
# Final Project
# Description:
# This code reads in a csv list of hgnc gene names, and annotates it using an API from proteinatlas.com. The code
# returns the genes' ensembl IDs, gene description, molecular function, biological function, and cell type in the form
# of a CSV. The program also asks the user if it is a specific type of tissue, so it can look for tissue specific cell
# types and cancer markers.

import sys
import mygene as mygene
import requests     # package imported to access API
import json     # package imported to help print API data
import biomart
conversionList = list()

# creation of a list of available tissues, their corresponding cell types, and cancer names, hard coded from the protein
# atlas website
tissues = [["colon", "colon enterocytes,colon enteroendocrine cells,enteric glia cells,mitotic cells,endothelial cells,"
                     "smooth muscle cells,fibroblasts,macrophages,neutrophils,mast cells,t-cells,plasma cells","Colorectal"],
           ["lung", "respiratory ciliated cells,alveolar cells type 1,alveolar cells type 2,mitotic cells,nk-cells,"
                    "b-cells,endothelial cells,smooth muscle cells,fibroblasts,macrophages,neutrophils,mast cells,t-cells,"
                    "plasma cells", "Lung"],
           ["pancreas", "alpha cells,beta cells,ductal cells,exocrine glandular cells,endothelial cells,fibroblasts,"
                        "macrophages,t-cells,plasma cells", "Pancreatic"],
           ["stomach", "parietal cells,chief cells,gastric mucous cells,gastric enteroendocrine cells,mitotic cells,"
                       "endothelial cells,fibroblasts,macrophages,neutrophils,t-cells,plasma cells", "Stomach"],
           ["thyroid", "parafollicular cells,thyroid glandular cells,mitotic cells,endothelial cells,smooth muscle cells,"
                       "fibroblasts,macrophages,neutrophils,t-cells,plasma cells", "Thyroid"],
           ["liver", "hepatocytes,cholangiocytes,endothelial cells,fibroblasts,"
                     "hepatic stellate cells", "Liver"],
           ["kidney", "podocytes,proximal tubular cells,ascending loop of henle cells,intercalated cells,fibroblasts,"
                      "macrophages,t-cells,plasma cells", "Renal"],
           ["adipose", "adipocytes,mesothelial cells,endothelial cells,smooth muscle cells,fibroblasts,macrophages,"
                       "neutrophils,mast cells,t-cells,plasma cells", "none"],
           ["breast", "breast glandular cells,breast myoepithelial cells,adipocytes,endothelial cells,smooth muscle cells,"
                      "fibroblasts,macrophages,t-cells,plasma cells", "none"],
           ["skeletal muscle", "skeletal myocytes,endothelial cells,smooth muscle cells,fibroblasts,macrophages,"
                               "neutrophils,plasma cells", "none"],
           ["heart muscle", "cardiomyocytes,mitotic cells,endothelial cells,smooth muscle cells,fibroblasts,macrophages,"
                            "neutrophils,t-cells,plasma cells", "none"],
           ["none of these", "NA,NA", "all"]]

immune = ["Kupffer cells", "Macrophages", "T-cells", "B-cells", "NK-cells", "Plasma cells",
          "monocytes"]


def gene_ensembleID_list():
    inFile = open("gene_ensembl_id.csv", "r")
    for line in inFile:
        conversion = line.strip().split(",")
        conversionList.append(conversion)
    inFile.close()


# function to print the names of the tissues from the tissues list, in order to allow the user to pick a number
def printTissue():
    num = 1
    print("Tissue Options:")
    for tissue in tissues:
        print("\t" + str(num) + ":" + tissue[0])
        num += 1


# function to split the cell types of the chosen number tissue into a list, to use in the match cell types function
def splitTissue(num):
    cellList = tissues[num-1][1].split(",")
    marker = tissues[num-1][2]
    return cellList, marker


# function to ask for all necessary user input: what file to read, what tissue type, and what file to write to
def userInput():
    fileName = input("What file name would you like to read in? ")
    printTissue()
    good = False
    while not good:     # iterates until user gives a valid integer answer
        tissueType = input("What tissue are you working with? (enter integer only): ")
        if not tissueType.isnumeric():
            print("please enter an integer")
        elif int(tissueType) < 1 or int(tissueType) > 12:
            print("please enter an integer between 1 and 12.")
        else:
            good = True
    cellList, marker = splitTissue(int(tissueType))
    outputName = input("What file would you like to save to? ")
    userAns = [fileName, cellList, marker, outputName]  # saves a list of the fileName string, the cell type List of
    # strings, the marker string, and the outputName string
    return userAns


# function that opens and reads the file under fileName and saves it as a list.
def readFile(fileName):
    inputFile = open(fileName, "r")
    info = list()
    for line in inputFile:
        info.append(line.strip().upper())
    inputFile.close()
    return info


# NEW function to get ensembl ID from hgnc gene
def get_ensembl_mappings(genelist):
    newGeneList = []
    for gene in genelist:
        for conversion in conversionList:
            if gene == conversion[1]:
                newGene = [gene, conversion[0]]
                newGeneList.append(newGene)
    return newGeneList



# New function to get ensembl ID for hgnc gene
# def get_ensembl_mappings(genelist):
#     mg = mygene.MyGeneInfo()
#     newGeneList = []
#
#     for gene in genelist:
#         result = mg.query(gene, scopes="symbol", fields=["ensembl"], species="human", verbose=False)
#         hgnc_name = gene
#         for hit in result["hits"]:
#             if "ensembl" in hit and "gene" in hit["ensembl"]:
#                 newGeneList.append([hgnc_name, hit["ensembl"]["gene"]])
#     return newGeneList


# function to find the ensembl ID for each hgnc gene name given, uses biomartAPI
# def get_ensembl_mappings(listName):
#     # Set up connection to server
#     server = biomart.BiomartServer('http://uswest.ensembl.org/biomart')
#     mart = server.datasets['hsapiens_gene_ensembl']
#     # mart.show_attributes()
#     # List the types of data we want
#     attributes = ['hgnc_symbol',
#                   'ensembl_gene_id']
#     # SEARCH PARAMETERS
#     response = mart.search({'attributes': attributes,
#         'filters': {'hgnc_symbol': listName}})
#     data = response.raw.data.decode('ascii') # this line puts data is alphabetical order
#     HGNC_to_ensembl = []
#     for line in data.splitlines():
#         line = line.split('\t')
#         # The entries are in the same order as in the `attributes` variable
#         hgnc = line[0]
#         ensembl_gene = line[1]
#         HGNC_to_ensembl.append([hgnc, ensembl_gene])
#     return HGNC_to_ensembl


# function to update original list of hgnc genes, to a list of lists of hgnc and ensemble IDs
# to be run after ensemble IDs are found
def organize(listName, geneList):
    for item in listName:  # iterates through listName, the original list of hgnc genes
        matched = False
        num = 0
        while not matched and num < len(geneList):
            if geneList[num][0] == item:
                listName[listName.index(item)] = [item, geneList[num][1]]   # updates the lists, at the index of the
                # matching hgnc gene, changes it to a list containing the hgnc gene and the corresponding ensemble ID
                matched = True
            num += 1
    return listName


# main annotating function, calls the protein atlas API, and using its dictionary, saves each gene's information by
# appending it to each gene's list
# uses helper function match cell types to look specifically for cell types of the user given tissue
# to be run after the organize function
def label(listName, userCellTypes, marker):
    function = ""
    baseURL = "http://www.proteinatlas.org/"
    for gene in listName:   # iterates through listName, gene is currently a list of strings: hgnc, and ensemblID
        search = baseURL + str(gene[1]) + ".json"
        response1 = requests.get(search)
        if response1.status_code == 200:    # only executes following code if ensembl ID is found in protein atlas
        # necessary due to differences in ensembl naming versions between each API, biomart is more updated
            responsejson1 = response1.json()
            # print(json.dumps(responsejson1, sort_keys=True, indent=4)) # used to read dictionary for testing
            geneDescription = responsejson1["Gene description"] # returns a string
            if "," in geneDescription:  # this code is run to make the conversion from a list to csv work in the end
                geneDescription = geneDescription.replace(",", ";")
            molecularFunction = responsejson1["Molecular function"] # returns a list of strings of molecular functions
            biologicalProcess = responsejson1["Biological process"]  # returns a list of strings
            if biologicalProcess is None and molecularFunction is None:
                function = "NA"
            elif molecularFunction is not None:   # not every gene has a molecular function, must have code to reflect that
                function = "; ".join(molecularFunction) # joined with a ; to make conversion to list to csv work
            if biologicalProcess is not None:   # not every gene has a biological process, must have code to reflect that
                function += "; " + "; ".join(biologicalProcess)

            cellType = responsejson1["RNA single cell type specific nTPM"]  # returns dictionary
            if cellType is not None:    # not every gene has an associated cell type, code must reflect this
                matchedCellTypes = matchCellTypes(userCellTypes, cellType)  # executes matchCellTypes helper function
                if matchedCellTypes == " ":
                    singleCell = responsejson1["Single cell expression cluster"]
                    for cell in userCellTypes:
                        if cell.capitalize() in singleCell:
                            matchedCellTypes += cell + "; "
                    for cell in immune:
                        if cell.capitalize() in singleCell:
                            matchedCellTypes += cell + "; "
                if matchedCellTypes == " ":
                    tissueExpression = responsejson1["Tissue expression cluster"]
                    for cell in userCellTypes:
                        if cell.capitalize() in tissueExpression:
                            matchedCellTypes += cell + "; "
                    for cell in immune:
                        if cell.capitalize() in tissueExpression:
                            matchedCellTypes += cell + "; "
                if matchedCellTypes == " ":
                    matchedCellTypes = readGraph(responsejson1, userCellTypes)
            else:
                matchedCellTypes = "NA"
            # the following code checks if gene is a cancer marker
            aMarker = ""
            if marker == "none":
                aMarker = "NA"
            elif marker == "all":
                for i in range(7):
                    search = "Pathology prognostics - " + tissues[i][2] + " cancer"
                    response = responsejson1[search]
                    if response is not None:
                        prognostic = response["is_prognostic"]     # returns a boolean
                        ptype = response["prognostic type"]    # returns a string
                        # print(str(prognostic), ptype)
                        if prognostic is True and ptype == "favorable":
                            aMarker += tissues[i][2] + " "   # saves any cancer markers of that gene
                if aMarker == "":
                    aMarker = "NA"
            else:
                search = "Pathology prognostics - " + marker + " cancer"    # makes search the name of the cancer
                # associated with chosen tissue
                response = responsejson1[search]
                if response is not None:
                    prognostic = response["is_prognostic"]     # returns a boolean
                    ptype = response["prognostic type"]    # returns a string
                    if prognostic is True:
                        aMarker = marker + " " + ptype
                    else:
                        aMarker = "NA"
            # appends all found info to the specific gene's list within the larger list of genes
            gene.append(geneDescription)
            gene.append(function)
            gene.append(matchedCellTypes)
            gene.append(aMarker)


# helper function to compare wantedTypes based on tissue choice to givenTypes from API
def matchCellTypes(wantedTypes, givenTypes):    # first is a list, second is a dictionary
    found = False
    foundTypes = []
    if wantedTypes[0] == "NA":
        # iterates if no wanted cell types were found, finds the cell type in the dictionary with the
        # highest value
        pastCell = 0
        for cell in givenTypes:
            if float(givenTypes[cell]) > pastCell:
                foundTypes = [cell]
            pastCell = float(givenTypes[cell])
        found = True
    if not found:
        for cell in wantedTypes:    # iterates through the wantedTypes list
            if cell.capitalize() in givenTypes:     # if the string is in the dictionary of givenTypes
                foundTypes.append(cell.capitalize())    # that cell type is appended to found types
                found = True
    if not found:
        for cell in immune:
            if cell.capitalize() in givenTypes:
                foundTypes.append(cell.capitalize())
                found = True
    if not found:
        foundTypes.append(" ")
    return " ".join(foundTypes)


def readGraph(responsejson, userCellTypes):
    graph = []
    for cell in userCellTypes:
        graph.append([cell.capitalize(), float(responsejson["Single Cell Type RNA - " + cell.capitalize() + " [nTPM]"])])
    for cell in immune:
        graph.append([cell, float(responsejson["Single Cell Type RNA - " + cell + " [nTPM]"])])
    greatestCell = 0
    # print(graph)
    for cell in graph:
        if cell[1] > greatestCell:
            foundTypes = cell[0]
            greatestCell = cell[1]
    return foundTypes

# function to print list of gene info lists to a csv, with name of user's choosing
def outputList(organizedList, fileName):
    outFile = open(fileName, "w")
    # print header for csv
    print("Gene Name,Ensemble ID,Gene Description,Biological Process/Molecular Function,Cell Types,Markers", file=outFile)
    for gene in organizedList:
        for geneInfo in gene:
            print(geneInfo + ",", end="", file=outFile)
        print("", file=outFile)
    outFile.close()


# main function to run all other functions
def main():
    gene_ensembleID_list()
    #print(conversionList)
    user = userInput()
    listName = readFile(user[0])
    # print(listName)
    mappings = get_ensembl_mappings(listName)
    # print(mappings)
    print("Working...")
    # organizedList = organize(listName, mappings)
    # print("...")
    # print(organizedList)
    label(mappings, user[1], user[2])
    print("...")
    #print(organizedList)
    outputList(mappings, user[3])
    print("done!")


main()  # calling of main
